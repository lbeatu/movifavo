import React from 'react'
//import PropTypes from 'prop-types';
import { Link } from 'react-router-dom'
const  Navbar =(probs) =>{
    
    
  
    // dont works  probs on react version 16.2.3 
    
        return (
            <nav className="navbar bg-dark">               
              <Link to='/'>
                <h1> 
                    <i className='fas fa-tape'/> Movifavo                 
                </h1>
               </Link>
            </nav>
        )
  
}/*
Navbar.defaultProbs={
        title: 'Github Finder',
        icon: 'fab fa-github'
    };

Navbar.propTypes= {
        title:PropTypes.string.isRequired,
        icon:PropTypes.string.isRequired

    };*/
export default Navbar
