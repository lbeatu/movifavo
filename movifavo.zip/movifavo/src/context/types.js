export const GET_MOVIES='GET_MOVIES';
export const REMOVE_MOVIE='REMOVE_MOVIE';
export const DETAILS_MOVIE='DETAILS_MOVIE';
export const SET_LOADING = 'SET_LOADING';
export const REMOVE_ALERT = 'REMOVE_ALERT';
export const SET_ALERT = 'SET_ALERT';
