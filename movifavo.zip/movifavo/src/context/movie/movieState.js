import React, { useReducer } from 'react';
import MovieContext from "./movieContext";
import MovieReducer from "./movieReducer";
import {
    DETAILS_MOVIE,
    SET_MOVIES,
    GET_MOVIES,
    SET_LOADING
} from '../types';

const movieState = props => {
    const initialState={
        movies:[],
        movie:[],
        favorite:null,
        loading: false
    }
    const [state, dispatch]=useReducer(MovieReducer, initialState);
 
    //Get movies
   const getFavorite= (fav , id)=>{
    setLoading();
  
   
        dispatch({
            type:SET_MOVIES,
            payload:""
        });
        
    };
    //get movie details
    const getMovieDetails = async id=>{
        setLoading();
        //console.log(movieDetails);
        fetch(`http://www.omdbapi.com/?i=${id}&apikey=24c4df7c`)
        .then(response => response.json())
        .then(jsonResponse => {
            console.log(jsonResponse);
            
          
        dispatch({
            type:DETAILS_MOVIE,
            payload:jsonResponse
        });
    }); 

    };
   const sendRequest = (title) => {
    setLoading();
    fetch(`http://www.omdbapi.com/?s=${title}\&plot=full\&apikey=24c4df7c`)
    .then(response => response.json())
    .then(jsonResponse => {
       console.log(jsonResponse);
     
    dispatch({
        type: GET_MOVIES,
        payload: jsonResponse.Search
    });
     });
    };

    const setLoading = () =>dispatch({type: SET_LOADING});
     
     return (<MovieContext.Provider
        value={{
            movies:state.movies,
            movie:state.movie,
            loading:state.loading,
            getFavorite,
            getMovieDetails,
            sendRequest        
        }}>
        {props.children}
    </MovieContext.Provider>
    );
};
export default movieState;