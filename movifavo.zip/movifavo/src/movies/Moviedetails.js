import React, { Fragment, useEffect, useContext} from 'react';
import { Link } from 'react-router-dom';
import MovieContext from '../context/movie/movieContext'
import Spinner from './Spinner';
import {
    Label,
    Input,
    Select,
    Textarea,
    Radio,
    Checkbox,

  } from '@rebass/forms'
import { Flex, Box } from 'reflexbox'
const Moviedetails = ({ match }) => {
    
    const  movieContext= useContext(MovieContext)
    const { movie,loading,getMovieDetails }=movieContext;
    const fav=1;
    useEffect(() => {
        getMovieDetails(match.params.imdbID);
        //eslint-disable-next-line
      }, []);
   
     const {
        Actors,
        Awards,
        BoxOffice,
        Country,
        DVD,
        Director,
        Genre,
        Language,
        Plot,
        Poster,
        Production,
        Title,
        Writer,
        Year,
        imdbRating,
        Runtime
    }=movie;
    const contents = Year + " - " +Genre+" · " + Runtime;
    const onClick=()=>{ movieContext.getFavorite(0,match.params.imdbID);
    };
    
   const onNotclick=()=>{ movieContext.getFavorite(1,match.params.imdbID);  };
   
   if(loading){ return <Spinner />;
   }else {
       
    return (       
        <div>
        <div className="card">
                <img src={Poster}
                alt="" 
                className="details-img"              
                />                       
                <p className="text-bar-title" >
                    {Title}
                </p>                
                 <p className="text-bar-details">{imdbRating}</p>                   
                <div className="container text-score">
                    <div  className="skills html " style={{width:'100px'}}> </div>
                </div>
                <h4 className="text-content-details" >
                    {contents}, </h4>
               <div className="cards-info">
                    <p>{Plot}</p>
               </div>
               </div>  
               <div className="card-actors">
                    <p>Language:<p className="p">{Language}</p></p>
                    <p>Production:<p className="p">{Production}</p></p>
                    <p>Country:<p className="p">{Country}</p></p>
                    <p>Awards:<p className="p">{Awards}</p></p>
                    <p>BoxOffice:<p className="p">{BoxOffice}</p></p>
                    <p>DVD:<p className="p">{DVD}</p></p>
                    <p>Director:<p className="p">{Director}</p></p>
                    <p>Writers:<p className="p">{Writer}</p></p>
                    <p>Stars:<p className="p">{Actors}</p></p>
               </div>

                   {fav ?  <Link to={`/movie/${match.params.imdbID}`} onClick={onClick} className="button-details">
                        + ADD TO WATCHLIST 
                   </Link>  
                   :
                    <Link to={`/`} onClick={onNotclick} className="button-details-remove">
                        - REMOVE FROM WATCHLIST 
                    </Link>    }
        </div>
       
    )
   };
}

export default Moviedetails;
