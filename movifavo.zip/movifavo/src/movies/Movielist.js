import React, { useState,useContext } from 'react';
import MovieContext from '../context/movie/movieContext';
import AlertContext from '../context/alert/alertContext'
import MovieItem from './MovieItem';
import { Button} from 'rebass';
import Spinner from './Spinner';
import {
    Label,
    Input,
    Select,
    Textarea,
    Radio,
    Checkbox,

  } from '@rebass/forms'
import { Flex, Box } from 'reflexbox'
import { ThemeProvider } from 'emotion-theming'
 const Movielist = () => {     
     
    const  movieContext= useContext(MovieContext)
    const  alertContext =useContext(AlertContext);

    const {movies,loading}=movieContext;
    const [text, setText]=useState('');        

  
    const onChange=(e)=> setText(e.target.value);  

    const onClick =(e)=>{
      e.preventDefault();
      if(text.length<=2){
        alertContext.setAlert('Title is too short.Try Again please..','light')
      }else{
        movieContext.sendRequest(text);
        setText('');
      }        
      
    };  
    
    if(loading){ return <Spinner />;
  } else {
    return (
    
    <ThemeProvider theme={{
            colors: {
              background: 'red',
              primary: '#0c2461',
            },
            space: [ 0, 6, 12, 24, 48 ],
            fontSizes: [ 14, 16, 18, 20, 24 ],
            radii: {
              default: 5,
            }
          }}>
     
      <Box
            as='form'
            onSubmit={e => e.preventDefault()}
            py={3}>
        <Flex mx={-2} mb={3}>
            <Box width={1/2} px={2}>
              <Input
                id='Search'
                name='Search'
                placeholder='Search movie'
                value={text}
                onChange={onChange}
              ></Input>
            </Box>    
            <Box width={1/2} px={1} mb={3} color='black'>
            <Button  onClick={onClick} >
                Beep
              </Button>
            </Box>
          </Flex>    
            <Box
              sx={{
                display: 'grid',
                gridGap: 6,
                gridTemplateColumns: 'repeat(auto-fit, minmax(256px, 1fr))',
              }}>
              {movies.map(movies =>(
                        <MovieItem key={movies.id} movies={movies}/>
                        ))} 
            </Box>
      </Box>
    </ThemeProvider>

    )
  };
};
export default Movielist
