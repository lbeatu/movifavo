import React from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import './App.css';
import Movielist from './movies/Movielist';
import moviedetails from './movies/Moviedetails'
import NotFound from './movies/NotFound'
import MovieState from './context/movie/movieState';
import AlertState from './context/alert/alertState';
import Navbar from './components/layouts/Navbar'
import Alert from './components/layouts/Alert';
const App =()=>{
 
    return (
      <MovieState>
        <AlertState>
           <Router>
            <div className="App">
            <Navbar />
            <div>
            <Alert alert={alert} />
            <Switch>
                  <Route exact path='/' component={Movielist} />
                  <Route  path='/movie/:imdbID' component={moviedetails} />    
                  <Route  component={NotFound} />
            </Switch>    
            </div>
            </div>
            </Router>   
            </AlertState> 
      </MovieState>

    );
  
}

export default App;
